﻿using LA.Model;
using LA.Repo.Interfaces;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LA.Repo.Implementations
{
    public class _DistrictRepo : IDistrictRepo
    {
        private readonly ApplicationDbContext _context;

        public _DistrictRepo(ApplicationDbContext context)
        {
            _context = context;
        }

        public void Edit(District district)
        {
            _context.districts.Update(district);
            _context.SaveChanges();
        }

        public IEnumerable<District> GetAll()
        {
            var districts = _context.districts.Include(x=>x.State).ThenInclude(y=>y.Country).ToList();
            return districts;

        }

        public District GetById(int id)
        {
            var districts = _context.districts.Find(id);
            return districts;
        }

        public void RemoveData(District district)
        {
            _context.districts.Remove(district);
            _context.SaveChanges();
        }

        public void Save(District district)
        {
            _context.districts.Add(district);
            _context.SaveChanges();
        }
    }
}
