﻿using LA.Model;
using LA.Repo.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LA.Repo.Implementations
{
    public class CountryRepo : ICountryRepo
    {
        private readonly ApplicationDbContext _context;

        public CountryRepo(ApplicationDbContext context)
        {
            _context = context;
        }

        public void Edit(Country country)
        {
            _context.countries.Update(country);
            _context.SaveChanges();
        }

        public IEnumerable<Country> GetAll()
        {
            var countries = _context.countries.ToList();
            return countries;
        }

        public Country GetById(int id)
        {
            var country = _context.countries.Find(id);
            return country;
        }

        public void RemoveData(Country country)
        {
            _context.countries.Remove(country);
            _context.SaveChanges();
        }

        public void Save(Country country)
        {
            _context. countries.Add(country);
            _context.SaveChanges(); 
        }
    }
}
