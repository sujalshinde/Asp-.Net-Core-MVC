﻿using LA.Model;
using LA.Repo.Interfaces;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LA.Repo.Implementations
{
    public class StateRepo : IStateRepo
    {
        private readonly ApplicationDbContext _context;

        public StateRepo(ApplicationDbContext context)
        {
            _context = context;
        }

        public void Edit(State state)
        {
            _context.states.Update(state);
            _context.SaveChanges();
        }

        public IEnumerable<State> GetAll()
        {
           var states= _context.states.Include (x=>x .Country).ToList();
            return states;
        }

        public State GetById(int id)
        {
            var state = _context.states.Find(id);
            return state;
        }

        public void RemoveData(State state)
        {
            _context.states.Remove(state);
            _context.SaveChanges();
        }

        public void Save(State state)


        { 
            _context.states.Add(state);
            _context.SaveChanges();
        }


    }
}
