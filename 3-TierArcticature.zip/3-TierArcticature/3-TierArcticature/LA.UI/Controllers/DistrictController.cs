﻿using LA.Model;
using LA.Repo.Implementations;
using LA.Repo.Interfaces;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;

namespace LA.UI.Controllers
{
    public class DistrictController : Controller
    {
        private readonly IDistrictRepo  _DistrictRepo;
        private readonly IStateRepo _StateRepo;

        public DistrictController(IDistrictRepo districtRepo, IStateRepo stateRepo)
        {
            _DistrictRepo = districtRepo;
            _StateRepo = stateRepo;
        }

        public IActionResult Index()
        {
            var district = _DistrictRepo.GetAll();
            return View(district);
        }

        [HttpGet]
        public IActionResult Create()
        {
            var states = _StateRepo.GetAll();
            ViewBag.StateList = new SelectList(states, "Id", "Name");
            return View();
        }

        [HttpPost]
        public IActionResult Create(District district)
        {
            _DistrictRepo.Save(district);
            return RedirectToAction("Index");
        }

        [HttpGet]
        public IActionResult Edit(int id)
        {
            var states = _StateRepo.GetAll();
            ViewBag.StateList = new SelectList(states, "Id", "Name");
            var district = _DistrictRepo.GetById(id);
            return View(district);
        }

        [HttpPost]
        public IActionResult Edit(District district)
        {
            _DistrictRepo.Edit(district);
            return RedirectToAction("Index");
        }

        public IActionResult Delete(int id)
        {
            var district =_DistrictRepo.GetById(id);
            _DistrictRepo.RemoveData(district);
            return RedirectToAction("Index");
        }

    }
}
