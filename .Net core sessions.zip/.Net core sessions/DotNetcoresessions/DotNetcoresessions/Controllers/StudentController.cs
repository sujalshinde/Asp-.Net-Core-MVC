﻿using DotNetcoresessions.data;
using DotNetcoresessions.Models;
using Microsoft.AspNetCore.Mvc;

namespace DotNetcoresessions.Controllers
{
    public class StudentController : Controller
    {
        private readonly ApplicationDbContext _context;

        public StudentController(ApplicationDbContext context)
        {
            _context = context;
        }

        public IActionResult Index()
        {
            var students = _context.Students.ToList();
            return View(students);
        }

        [HttpGet]
        public IActionResult Create()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Create(students student)
        {
            _context.Students.Add(student);
            _context.SaveChanges();


            return RedirectToAction("Index");
        }

        [HttpGet]

        public IActionResult Edit(int id)
        {
            var students = _context.Students.Find(id);
            return View(students);
        }

        [HttpPost]

        public IActionResult Edit(students student)
        {
            _context.Students.Update(student);
            _context.SaveChanges();
            return RedirectToAction("Index");
        }

        [HttpGet]

        public IActionResult Delete(int id)
        {
            var students = _context.Students.Find(id);
            return View(students);
        }

        [HttpPost]

        public IActionResult Delete(students student)
        {
            _context.Students.Remove(student);
            _context.SaveChanges();
            return RedirectToAction("Index");
        }
    }
}
