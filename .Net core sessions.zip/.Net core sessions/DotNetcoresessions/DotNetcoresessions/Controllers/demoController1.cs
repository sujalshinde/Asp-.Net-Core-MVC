﻿using Microsoft.AspNetCore.Mvc;

namespace DotNetcoresessions.Controllers
{
    public class demoController1 : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
        public IActionResult history()
        {
            return View();
        }
    }
     
    }
