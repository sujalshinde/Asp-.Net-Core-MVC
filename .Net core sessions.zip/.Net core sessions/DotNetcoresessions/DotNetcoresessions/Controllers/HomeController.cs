using System.Diagnostics;
using DotNetcoresessions.Models;
using Microsoft.AspNetCore.Mvc;

namespace DotNetcoresessions.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;

        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }

        public IActionResult Index()
        {
            //int a = 70;
            //return View(a);

            //students student = new students();
            //student.Id = 1;
            //student.Name = "Ram";
            //student.City = "Pune";
            //return View(student);


            List<students> students = new List<students>();
            students.Add(new students { Id = 1, Name = "Ram", City = "Pune" });
            students.Add(new students { Id = 2, Name = "Shree", City = "Mumbai" });
            students.Add(new students { Id = 2, Name = "Subhash", City = "Kolkata" });
            students.Add(new students { Id = 3, Name = "Narendra", City = "Chennai" });
            return View(students);

            //return View();

        }

        

        public IActionResult Privacy()
        {
            return View();
        }
        public IActionResult history()
        {
            return View();
        }

        public IActionResult Student()
        {
            return View();
        }



        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
